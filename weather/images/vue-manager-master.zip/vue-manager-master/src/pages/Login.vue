<template>
  <div class="login">
    <VmLogin>
    </VmLogin>
  </div>
</template>
<script>
  import VmLogin from '@/components/vm-login'
  export default {
    name: 'Login',
    components: {
      VmLogin
    }
  }
</script>
